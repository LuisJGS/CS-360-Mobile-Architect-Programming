package com.zybooks.inventoryapp;

import static com.zybooks.inventoryapp.R.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.List;

public class InventoryListActivity extends AppCompatActivity {

    //tag from logcat
    private static final String TAG = "InventoryList";

    //inventory items
    private List<ItemActivity> aItemList;

    InventoryDB inventoryDatabase;

    RecyclerView itemListView;
    TextView emptyListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //set transitions
        overridePendingTransition(anim.slide_in_left, anim.slide_out_right);
        setContentView(layout.activity_inventory_list);

        //Initialize DB and get items
        inventoryDatabase = InventoryDB.getInstance(getApplicationContext());
        aItemList = inventoryDatabase.getItems();

        //set up the recycler
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        itemListView = findViewById(id.itemListView);
        itemListView.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(itemListView.getContext(),
                layoutManager.getOrientation());
        itemListView.addItemDecoration(dividerItemDecoration);

        //find the view
        emptyListView = findViewById(id.emptyListView);

        //send items to recycler
        AdapterActivity adapter = new AdapterActivity(aItemList, this, inventoryDatabase);
        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                checkListIsEmpty();
            }
        });

        itemListView.setAdapter(adapter);

        //Check if the list is empty
        checkListIsEmpty();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Show the app bar menu
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.action_add_item:
                //create new item
                Log.d(TAG, "New item view");
                intent = new Intent(getApplicationContext(), EditActivity.class);
                startActivity(intent);
                return true;

            case R.id.action_toggle_notifications:
                // Switch to the notifications setting screen
                Log.d(TAG, "SMS Notifications view");
                intent = new Intent(getApplicationContext(), SmsActivity.class);
                startActivity(intent);
                return true;

            case id.action_logout:
                // Log the user out by returning to the login screen
                Log.d(TAG, "Logging out");
                intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void checkListIsEmpty() {
        Log.d(TAG, "Inventory size: " + aItemList.size());
        if (aItemList.isEmpty()) {
            itemListView.setVisibility(View.GONE);
            emptyListView.setVisibility(View.VISIBLE);
        } else {
            itemListView.setVisibility(View.VISIBLE);
            emptyListView.setVisibility(View.GONE);
        }
    }
}
