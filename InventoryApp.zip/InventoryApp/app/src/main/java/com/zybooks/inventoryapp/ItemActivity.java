package com.zybooks.inventoryapp;

import java.io.Serializable;

public class ItemActivity implements Serializable {
    private String aName;
    private long aId;
    private int qty;

    //constructor
    public ItemActivity() {
    }

    //constructor for item
    public ItemActivity(String name, long id) {
        aId = id;
        aName = name;
        qty = 0;
    }

    //Constructor for
    //qty, ID and name of item

    public ItemActivity(String name, long id, int quantity) {
        aName = name;
        aId = id;
        qty = quantity;
    }

    public long getId() {
        return aId;
    }

    public void setId(long id) {
        this.aId = id;
    }

    public String getName() {
        return aName;
    }

    public void setName(String name) {
        this.aName = name;
    }

    public int getQuantity() {
        return qty;
    }

    //set
    public void setQuantity(int qty) {
        this.qty = Math.max(0, qty);
    }

    //add to qty
    public void incrementQuantity() {
        this.qty++;
    }

    //decrease qty
    public void decrementQuantity() {
        this.qty = Math.max(0, this.qty - 1);
    }
}
