package com.zybooks.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.MessageDigest;

public class Login extends AppCompatActivity {

    InventoryDB inventoryDatabase;

    EditText usernameInput;
    EditText passwordInput;

    Button loginButton;
    Button signUpButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //singleton instance from db
        inventoryDatabase = InventoryDB.getInstance(this);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);

        loginButton = findViewById(R.id.loginButton);
        signUpButton = findViewById(R.id.signUpButton);

        //Disable buttons
        loginButton.setEnabled(false);
        signUpButton.setEnabled(false);

        //listen text changes
        usernameInput.addTextChangedListener(textWatcher);
        passwordInput.addTextChangedListener(textWatcher);
    }

    //activating log in button
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            boolean fieldsAreEmpty = getUsername().isEmpty() || getPassword().isEmpty();
            loginButton.setEnabled(!fieldsAreEmpty);
            signUpButton.setEnabled(!fieldsAreEmpty);
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    //trying to log in
    public void login(View view) {
        //Validate the credentials
        if (!validCredentials()) {
            showError(view.getContext().getResources().getString(R.string.invalid_login));
            return;
        }

        try {
            boolean isLoggedIn = inventoryDatabase.checkUser(getUsername(), hash(getPassword()));

            if (isLoggedIn) {
                handleLoggedInUser();
            } else {
                showError(view.getContext().getResources().getString(R.string.invalid_login));
            }
        } catch (Exception e) {
            showError(view.getContext().getResources().getString(R.string.invalid_login));
        }
    }

    //sign up new user
    public void register(View view) {
        //making sure credentials are valid
        if (!validCredentials()) {
            showError(view.getContext().getResources().getString(R.string.registration_error));
        }

        try {
            //creating a user
            boolean userCreated = inventoryDatabase.addUser(getUsername(), hash(getPassword()));

            //go to inventory list if user was created
            if (userCreated) {
                handleLoggedInUser();
            } else {
                showError(view.getContext().getResources().getString(R.string.registration_error));
            }
        } catch (Exception e) {
            showError(view.getContext().getResources().getString(R.string.registration_error));
        }
    }

    //inventory list navigation
    private void handleLoggedInUser() {
        Intent intent = new Intent(getApplicationContext(), InventoryListActivity.class);
        startActivity(intent);
    }

    //check if the credentials are not empty
    private boolean validCredentials() {
        return !getUsername().isEmpty() && !getPassword().isEmpty();
    }

    //get the username
    private String getUsername() {
        Editable username = usernameInput.getText();
        return username != null ? username.toString().trim().toLowerCase() : "";
    }

    //get password
    private String getPassword() {
        Editable password = passwordInput.getText();
        return password != null ? password.toString().trim() : "";
    }

    //hash function for password
    private String hash(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(password.getBytes());
        byte[] digest = md.digest();
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
            sb.append(String.format("%02x", b & 0xff));
        }

        return sb.toString();
    }

    //helper to show Toast error
    private void showError(String errorMessage) {
        Toast toast = Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, -200);
        toast.show();
    }
}
