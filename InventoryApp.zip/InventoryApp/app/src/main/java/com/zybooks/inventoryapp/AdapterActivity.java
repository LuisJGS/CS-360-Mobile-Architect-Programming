package com.zybooks.inventoryapp;

import static com.zybooks.inventoryapp.R.*;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdapterActivity extends RecyclerView.Adapter<AdapterActivity.ItemHolder> {

    //Logcat tag
    private static final String TAG = "AdapterActivity";

    //Collection
    private final List<ItemActivity> aItems;
    private final Context context;

    InventoryDB inventoryDB;

    //Constructor for lists
    public AdapterActivity(List<ItemActivity> items, Context ctx, InventoryDB inventoryDb) {
        aItems = items;
        context = ctx;
        inventoryDB = inventoryDb;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //child view
        final View view = LayoutInflater.from(parent.getContext()).inflate(layout.inventory_item, parent, false);
        return new ItemHolder(view, inventoryDB);
    }

    @Override
    public void onBindViewHolder(ItemHolder holder, @SuppressLint("RecyclerView") int position) {
        //find the inventory item
        ItemActivity item = aItems.get(position);
        holder.bind(item);

        //click "more actions" button
        holder.aItemActionsBtn.setOnClickListener(v -> {
            //Show a popup menu
            PopupMenu popup = new PopupMenu(context, holder.aItemActionsBtn);
            popup.inflate(menu.inventory_item_actions_menu);
            popup.setOnMenuItemClickListener(menuItem -> {
                switch (menuItem.getItemId()) {
                    case id.menu_edit:
                        //navigate to edit screen and pass item
                        Log.i(TAG, "edit item at position " + position);

                        Intent intent = new Intent(context, EditActivity.class);
                        intent.putExtra(EditActivity.EXTRA_ITEM, item);
                        context.startActivity(intent);

                        return true;
                    case id.menu_remove:
                        //Delete the current item from the database and the list
                        Log.i(TAG, "remove item at position " + position);

                        //wrapping the delete action
                        new AlertDialog.Builder(context).setIcon(android.R.drawable.ic_dialog_alert)
                                .setTitle(R.string.delete_confirmation_title).setMessage(R.string.delete_confirmation)
                                .setPositiveButton("Yes", (dialog, which) -> {
                                    //delete item from db
                                    boolean deleted = inventoryDB.deleteItem(item);
                                    if (deleted) {
                                        //remove item from list
                                        aItems.remove(position);
                                        notifyItemRemoved(position);
                                        notifyDataSetChanged();
                                    } else {
                                        //show error message
                                        Toast.makeText(context, string.delete_error, Toast.LENGTH_SHORT).show();
                                    }
                                }).setNegativeButton("No", null).show();

                        return true;
                    default:
                        return false;
                }
            });
            //displaying the popup
            popup.show();
        });
    }

    @Override
    public int getItemCount() {
        return aItems.size();
    }

    static class ItemHolder extends RecyclerView.ViewHolder {

        //view references
        private ItemActivity aItem;
        private final TextView aNameTextView;
        private final EditText aQuantityView;

        //db
        InventoryDB inventoryDatabase;

        ImageButton aDecreaseQuantityBtnInline;
        ImageButton aIncreaseQuantityBtnInline;
        ImageButton aItemActionsBtn;

        public ItemHolder(View itemView, InventoryDB inventoryDb) {
            super(itemView);
            inventoryDatabase = inventoryDb;
            aNameTextView = itemView.findViewById(id.itemName);
            aQuantityView = itemView.findViewById(id.editQuantity);
            aDecreaseQuantityBtnInline = itemView.findViewById(id.decreaseQuantityBtnInline);
            aIncreaseQuantityBtnInline = itemView.findViewById(id.increaseQuantityBtnInline);
            aItemActionsBtn = itemView.findViewById(id.itemActionsBtn);

            // Update when button is pressed
            aDecreaseQuantityBtnInline.setOnClickListener(v -> {
                aItem.decrementQuantity();
                boolean updated = inventoryDatabase.updateItem(aItem);
                if (updated) {
                    aQuantityView.setText(String.valueOf(aItem.getQuantity()));
                }
            });

            //Update when button is pressed
            aIncreaseQuantityBtnInline.setOnClickListener(v -> {
                aItem.incrementQuantity();
                boolean updated = inventoryDatabase.updateItem(aItem);
                if (updated) {
                    aQuantityView.setText(String.valueOf(aItem.getQuantity()));
                }
            });

            //changes on the quantity
            aQuantityView.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                    aItem.setQuantity(getItemQuantity());
                    boolean updated = inventoryDatabase.updateItem(aItem);
                    Log.d(TAG, "Item quantity updated: " + updated);

                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });
        }

        //bind model
        public void bind(ItemActivity item) {
            aItem = item;
            Log.d("ItemHolder", "Bind item: " + item.getName());
            aNameTextView.setText(item.getName());
            aQuantityView.setText(String.valueOf(item.getQuantity()));
        }


        private int getItemQuantity() {
            String rawValue = aQuantityView.getText().toString().replaceAll("[^\\d.]", "").trim();
            int quantity = rawValue.isEmpty() ? 0 : Integer.parseInt(rawValue);

            //Quantity not less 0
            return Math.max(quantity, 0);
        }
    }
}
