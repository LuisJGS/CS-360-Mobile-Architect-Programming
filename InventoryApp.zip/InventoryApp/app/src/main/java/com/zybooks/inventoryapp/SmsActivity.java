package com.zybooks.inventoryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.switchmaterial.SwitchMaterial;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;



public class SmsActivity extends AppCompatActivity {

    //logcat tag
    private static final String TAG = "SmsNotificationsActivity";

    public static String PREFERENCE_RECEIVE_NOTIFICATIONS = "pref_receive_notifications";

    //permissions code
    private final int REQUEST_SEND_SMS_CODE = 0;

    SwitchMaterial notificationsToggle;

    SharedPreferences sharedPrefs;

    boolean receiveNotifications = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.activity_sms_notifcations);

        notificationsToggle = findViewById(R.id.notificationsToggle);

        //changes to the toggle switch
        notificationsToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            receiveNotifications = isChecked;
            //check for permissions
            if (isChecked && hasPermissions()) {
                Log.d(TAG, "Wants to receive notifications");
                notificationsToggle.setChecked(true);
            } else {
                Log.d(TAG, "Does not want to receive notifications");
                notificationsToggle.setChecked(false);
                receiveNotifications = false;
            }

            //user preferences app
            savePreferences();
        });

        //access shared preference
        sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        receiveNotifications = sharedPrefs.getBoolean(PREFERENCE_RECEIVE_NOTIFICATIONS, false);

        //setting the toggle switch
        if (receiveNotifications
                && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED
        ) {
            notificationsToggle.setChecked(true);
        }
    }

    //check permission
    private boolean hasPermissions() {
        String smsPermission = Manifest.permission.SEND_SMS;

        if (ContextCompat.checkSelfPermission(this, smsPermission)
                != PackageManager.PERMISSION_GRANTED) {

            //check again
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, smsPermission)) {
                //show dialog box
                new AlertDialog.Builder(this)
                        .setTitle(R.string.sms_notification_title)
                        .setMessage(R.string.sms_notification)
                        .setPositiveButton("OK", (dialog, which) -> {
                            // Actually request permission from the user
                            ActivityCompat.requestPermissions(
                                    SmsActivity.this,
                                    new String[]{smsPermission},
                                    REQUEST_SEND_SMS_CODE
                            );
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                        .create()
                        .show();
            } else {
                //request permissions
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{smsPermission},
                        REQUEST_SEND_SMS_CODE
                );
            }
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_SEND_SMS_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "Permission granted");
                    receiveNotifications = true;
                    notificationsToggle.setChecked(true);
                } else {
                    // Permission denied!
                    Log.d(TAG, "Permission denied");
                    receiveNotifications = false;
                    notificationsToggle.setChecked(false);
                }
                savePreferences();
            }
        }
    }

    //save preference
    private void savePreferences() {
        SharedPreferences.Editor editor = sharedPrefs.edit();
        editor.putBoolean(PREFERENCE_RECEIVE_NOTIFICATIONS, receiveNotifications);
        editor.apply();
    }
}
