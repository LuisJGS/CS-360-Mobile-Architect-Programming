package com.zybooks.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//works for inventory item
public class EditActivity extends AppCompatActivity {

    //The name of key to use
    public static final String EXTRA_ITEM = "com.zybooks.inventoryapp.itemActivity";

    //inventory database
    InventoryDB inventoryDatabase;

    //views
    EditText itemName;
    EditText itemQuantity;

    //button for add and deleting
    Button saveBtn;
    Button deleteItemBtn;
    private ItemActivity mItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //set up view
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.activity_edit_item);

        inventoryDatabase = InventoryDB.getInstance(this);

        itemName = findViewById(R.id.editItemName);
        itemQuantity = findViewById(R.id.editQuantity_edit);
        deleteItemBtn = findViewById(R.id.deleteItemBtn);
        saveBtn = findViewById(R.id.saveItem);

        //Set action buttons
        deleteItemBtn.setVisibility(View.GONE);
        saveBtn.setEnabled(false);

        int initialQuantity = 0;

        //check if there was an item passed
        ItemActivity item = (ItemActivity) getIntent().getSerializableExtra(EXTRA_ITEM);
        if (item != null) {
            mItem = item;
            itemName.setText(item.getName());
            initialQuantity = item.getQuantity();
            deleteItemBtn.setVisibility(View.VISIBLE);
        }

        //set quantity value
        itemQuantity.setText(String.valueOf(initialQuantity));

        //changes to item name or item quantity
        itemName.addTextChangedListener(textWatcher);
        itemQuantity.addTextChangedListener(textWatcher);
    }

    //text changes
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            saveBtn.setEnabled(!getItemName().isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    //insert item
    public void handleSaveItem(View view) {
        boolean saved;

        if (mItem != null) {
            mItem.setName(getItemName());
            mItem.setQuantity(getItemQuantity());
            saved = inventoryDatabase.updateItem(mItem);
        } else {
            //create new item
            saved = inventoryDatabase.addItem(getItemName(), getItemQuantity());
        }

        //if the item saved go previous screen
        if (saved) {
            NavUtils.navigateUpFromSameTask(this);
        } else {
            Toast.makeText(EditActivity.this, R.string.save_error, Toast.LENGTH_SHORT).show();
        }
    }

    //handle deleting the current item
    public void handleDeleteItem(View view) {
        new AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle(R.string.delete_confirmation_title).setMessage(R.string.delete_confirmation)
                .setPositiveButton("Yes", (dialog, which) -> {
                    // Delete the item from the database
                    boolean deleted = inventoryDatabase.deleteItem(mItem);
                    finish();

                    //If successfully deleted
                    if (deleted) {
                        NavUtils.navigateUpFromSameTask(EditActivity.this);
                    } else {
                        Toast.makeText(EditActivity.this, R.string.delete_error, Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("No", null).show();
    }

    //adding to item qty
    public void incrementQuantity(View view) {
        itemQuantity.setText(String.valueOf(getItemQuantity() + 1));
    }

    //decrease
    public void decrementQuantity(View view) {
        itemQuantity.setText(String.valueOf(Math.max(0, getItemQuantity() - 1)));
    }

    private String getItemName() {
        Editable name = itemName.getText();
        return name != null ? name.toString().trim() : "";
    }

    private int getItemQuantity() {
        String rawValue = itemQuantity.getText().toString().replaceAll("[^\\d.]", "").trim();
        int quantity = rawValue.isEmpty() ? 0 : Integer.parseInt(rawValue);

        //Qty =< 0
        return Math.max(quantity, 0);
    }
}
